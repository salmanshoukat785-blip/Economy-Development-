@file:OptIn(ExperimentalMaterial3Api::class)

package com.pmsnotes.economy

import android.content.Context
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine
import org.json.JSONArray

// ---------------------------------------------------------------- storage and state

class Store(context: Context) {
    private val sp = context.getSharedPreferences("pms_store", Context.MODE_PRIVATE)
    fun getSet(key: String): Set<String> = sp.getStringSet(key, emptySet()) ?: emptySet()
    fun putSet(key: String, v: Set<String>) { sp.edit().putStringSet(key, HashSet(v)).apply() }
    fun getInt(key: String, def: Int): Int = sp.getInt(key, def)
    fun putInt(key: String, v: Int) { sp.edit().putInt(key, v).apply() }
    fun getFloat(key: String, def: Float): Float = sp.getFloat(key, def)
    fun putFloat(key: String, v: Float) { sp.edit().putFloat(key, v).apply() }
    fun getString(key: String): String = sp.getString(key, "") ?: ""
    fun putString(key: String, v: String) { sp.edit().putString(key, v).apply() }
    fun getBool(key: String, def: Boolean): Boolean = sp.getBoolean(key, def)
    fun putBool(key: String, v: Boolean) { sp.edit().putBoolean(key, v).apply() }
}

class AppState(private val store: Store) {
    val bookmarks = mutableStateListOf<Int>()
    val done = mutableStateListOf<Int>()
    val best = mutableStateMapOf<Int, Int>()
    val notes = mutableStateMapOf<Int, String>()
    var textScale by mutableStateOf(store.getFloat("scale", 1.0f))
    var welcomed by mutableStateOf(store.getBool("welcomed", false))
    var sessions by mutableStateOf(store.getInt("sessions", 0))
    var mockBest by mutableStateOf(store.getInt("mock_best", -1))

    init {
        store.getSet("bm").forEach { s -> s.toIntOrNull()?.let { bookmarks.add(it) } }
        store.getSet("done").forEach { s -> s.toIntOrNull()?.let { done.add(it) } }
        store.getSet("best").forEach { s ->
            val p = s.split(":")
            if (p.size == 2) {
                val a = p[0].toIntOrNull()
                val b = p[1].toIntOrNull()
                if (a != null && b != null) best[a] = b
            }
        }
        for (n in 1..60) {
            val t = store.getString("note_$n")
            if (t.isNotEmpty()) notes[n] = t
        }
    }

    fun toggleBookmark(no: Int) {
        if (bookmarks.contains(no)) bookmarks.remove(no) else bookmarks.add(no)
        store.putSet("bm", bookmarks.map { it.toString() }.toSet())
    }

    fun toggleDone(no: Int) {
        if (done.contains(no)) done.remove(no) else done.add(no)
        store.putSet("done", done.map { it.toString() }.toSet())
    }

    fun recordScore(no: Int, score: Int) {
        val old = best[no] ?: -1
        if (score > old) {
            best[no] = score
            store.putSet("best", best.map { "${it.key}:${it.value}" }.toSet())
        }
    }

    fun recordMock(score: Int) {
        if (score > mockBest) {
            mockBest = score
            store.putInt("mock_best", score)
        }
    }

    fun setNote(no: Int, text: String) {
        notes[no] = text
        store.putString("note_$no", text)
    }

    fun updateScale(v: Float) {
        textScale = v
        store.putFloat("scale", v)
    }

    fun markWelcomed() {
        welcomed = true
        store.putBool("welcomed", true)
    }

    fun addSession() {
        sessions += 1
        store.putInt("sessions", sessions)
    }

    fun resetProgress() {
        bookmarks.clear()
        done.clear()
        best.clear()
        mockBest = -1
        sessions = 0
        store.putSet("bm", emptySet())
        store.putSet("done", emptySet())
        store.putSet("best", emptySet())
        store.putInt("mock_best", -1)
        store.putInt("sessions", 0)
    }
}

val LocalApp = staticCompositionLocalOf<AppState> { error("AppState not provided") }

// ---------------------------------------------------------------- logo, splash, welcome

@Composable
fun AppLogo(dp: Dp) {
    Canvas(Modifier.size(dp)) {
        val w = size.width
        fun p(v: Float): Float = w * (0.5f + (v - 54f) * 1.2f / 108f)
        drawRoundRect(color = Navy, cornerRadius = CornerRadius(w * 0.22f, w * 0.22f))
        val bars = listOf(Pair(32f, 58f), Pair(46f, 48f), Pair(60f, 36f))
        bars.forEach { b ->
            drawRect(
                color = Color.White,
                topLeft = Offset(p(b.first), p(b.second)),
                size = androidx.compose.ui.geometry.Size(p(b.first + 9f) - p(b.first), p(72f) - p(b.second))
            )
        }
        val gold = Color(0xFFF2B233)
        val sw = w * 3.5f * 1.2f / 108f
        val trend = listOf(Pair(30f, 50f), Pair(46f, 41f), Pair(58f, 32f), Pair(77f, 21f))
        for (i in 0 until trend.size - 1) {
            drawLine(gold, Offset(p(trend[i].first), p(trend[i].second)), Offset(p(trend[i + 1].first), p(trend[i + 1].second)), sw, StrokeCap.Round)
        }
        drawLine(gold, Offset(p(67f), p(20f)), Offset(p(77.5f), p(20.5f)), sw, StrokeCap.Round)
        drawLine(gold, Offset(p(77.5f), p(20.5f)), Offset(p(76f), p(31f)), sw, StrokeCap.Round)
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    val alpha by animateFloatAsState(targetValue = if (shown) 1f else 0f, animationSpec = tween(900), label = "splashAlpha")
    LaunchedEffect(Unit) {
        shown = true
        delay(2200)
        onDone()
    }
    Box(Modifier.fillMaxSize().background(Navy), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.alpha(alpha)) {
            AppLogo(130.dp)
            Spacer(Modifier.height(20.dp))
            Text("Economy and Development", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Text("Punjab PMS", color = Color(0xFFBFD3E6), fontSize = 14.sp)
        }
    }
}

@Composable
fun WelcomeScreen(onStart: () -> Unit, onGuide: () -> Unit) {
    val features = listOf(
        "56 topics with Short and Long detail",
        "Underlined vocabulary with Urdu meanings",
        "Key points, differences and course outline",
        "560 MCQs, timed tests and a 25-question mock test",
        "Bookmarks, progress tracking and your own notes",
        "Study timer and adjustable text size",
        "Works fully offline"
    )
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Navy),
        contentPadding = PaddingValues(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Spacer(Modifier.height(24.dp)) }
        item { AppLogo(110.dp) }
        item {
            Text("Welcome", color = Color(0xFFF2B233), fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        item {
            Text("Economy and Development", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
        item {
            Text(
                "Study companion for Punjab PMS Economy and Development (100 marks: 25 MCQs + 75 subjective).",
                color = Color(0xFFBFD3E6),
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )
        }
        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("What is inside", fontWeight = FontWeight.Bold, color = Navy)
                    features.forEach { f -> Text("• $f", fontSize = 14.sp, color = Ink) }
                }
            }
        }
        item {
            Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) { Text("Get Started") }
        }
        item {
            TextButton(onClick = onGuide) { Text("Read the User Guide", color = Color.White) }
        }
    }
}

// ---------------------------------------------------------------- guide, settings, timer

@Composable
fun SimpleTopBar(title: String, onBack: () -> Unit) {
    TopAppBar(
        title = { Text(title, fontSize = 16.sp) },
        navigationIcon = { TextButton(onClick = onBack) { Text("Back", color = Color.White) } },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Color.White)
    )
}

@Composable
fun GuideScreen(onBack: () -> Unit) {
    val steps = listOf(
        Pair("1. Home screen", "The home screen has four tabs: Topics, Course Outline, Topic Outline and Mock Test. Use the Menu button at the top for the User Guide, Study Timer, Settings and Welcome page."),
        Pair("2. Topics tab", "Tap a topic to open it. Use the search box to find a topic or term. Filters show All topics, Saved topics (star) or Pending topics you have not completed. The bar at the top shows your overall progress."),
        Pair("3. Notes: Short and Long detail", "Inside a topic, the Notes tab lists numbered headings. Use the switch to change between Short points and Long detail for every heading. The yellow box at the end gives the differences with symbols."),
        Pair("4. Vocabulary with Urdu meanings", "Underlined blue words in the notes are vocabulary terms. Tap a word to see its Urdu meaning in a pop-up. The Vocabulary tab lists every term used in the topic with its Urdu meaning."),
        Pair("5. Key Points", "The Key Points tab gives quick facts, formulas and differences for fast revision."),
        Pair("6. MCQs", "Each topic has 10 MCQs. In Practice mode, tap an option to see right or wrong at once and your score. Switch on Timed test for 30 seconds per question: press Start, answers are shown when the test ends, and your best score is saved."),
        Pair("7. Mock Test", "The Mock Test tab makes a paper of 25 random MCQs from all topics with a 25-minute timer, like the MCQ part of the paper. You can submit early, then review every answer. Your best mock score is saved."),
        Pair("8. Save and complete", "Inside a topic, use Save to star a topic and Mark as completed when you finish it. Both are stored on your phone and used by the filters and progress bar."),
        Pair("9. My Notes", "The My Notes tab lets you type your own notes for a topic. They save automatically."),
        Pair("10. Course Outline", "The Course Outline tab shows the syllabus lines from the official outline file. Tap any line to open the matching topic. Topic Outline shows all headings of every topic."),
        Pair("11. Study Timer", "Open Menu, then Study Timer. Choose 15, 25, 45 or 60 minutes, press Start, and the app counts completed sessions."),
        Pair("12. Settings", "Menu, then Settings lets you change the text size and reset your progress."),
        Pair("13. Offline use", "All notes, MCQs and vocabulary are inside the app, so it works without internet and uses no mobile data."),
        Pair("14. Important note", "Figures are approximate. Check the latest PPSC syllabus, Pakistan Economic Survey and SBP data for current numbers.")
    )
    Scaffold(topBar = { SimpleTopBar("User Guide", onBack) }) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(steps) { i, s ->
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = if (i % 2 == 0) Light else Color.White)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(s.first, fontWeight = FontWeight.Bold, color = Teal, fontSize = 14.sp)
                        Text(s.second, fontSize = 14.sp, color = Ink)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val app = LocalApp.current
    var confirm by remember { mutableStateOf(false) }
    val options = listOf(Pair("Small", 0.9f), Pair("Normal", 1.0f), Pair("Large", 1.15f), Pair("Extra large", 1.3f))
    Scaffold(topBar = { SimpleTopBar("Settings", onBack) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Text size", fontWeight = FontWeight.Bold, color = Navy)
            options.forEach { o ->
                val selected = app.textScale == o.second
                if (selected) {
                    Button(onClick = { app.updateScale(o.second) }, modifier = Modifier.fillMaxWidth()) { Text("${o.first} (selected)") }
                } else {
                    OutlinedButton(onClick = { app.updateScale(o.second) }, modifier = Modifier.fillMaxWidth()) { Text(o.first) }
                }
            }
            Text("Sample: GDP measures the value of final goods and services produced in a country.", fontSize = 14.sp)
            Text("Progress", fontWeight = FontWeight.Bold, color = Navy)
            Text("Completed topics: ${app.done.size}, saved topics: ${app.bookmarks.size}, study sessions: ${app.sessions}", fontSize = 13.sp)
            OutlinedButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) { Text("Reset progress") }
            Text("About", fontWeight = FontWeight.Bold, color = Navy)
            Text("Economy and Development, version 2.0. Based on the Punjab PMS Economy and Development outline. Verify with the latest official PPSC syllabus.", fontSize = 13.sp)
        }
        if (confirm) {
            AlertDialog(
                onDismissRequest = { confirm = false },
                title = { Text("Reset progress?") },
                text = { Text("Completed topics, saved topics, best scores and study sessions will be cleared. Your own notes are kept.") },
                confirmButton = { TextButton(onClick = { app.resetProgress(); confirm = false }) { Text("Reset") } },
                dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
            )
        }
    }
}

@Composable
fun TimerScreen(onBack: () -> Unit) {
    val app = LocalApp.current
    var minutes by rememberSaveable { mutableStateOf(25) }
    var left by rememberSaveable { mutableStateOf(25 * 60) }
    var running by remember { mutableStateOf(false) }
    var completed by remember { mutableStateOf(false) }

    LaunchedEffect(running) {
        while (running && left > 0) {
            delay(1000)
            left -= 1
        }
        if (running) {
            running = false
            completed = true
            app.addSession()
        }
    }

    Scaffold(topBar = { SimpleTopBar("Study Timer", onBack) }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(15, 25, 45, 60).forEach { m ->
                    if (m == minutes) {
                        Button(onClick = {}) { Text("$m min") }
                    } else {
                        OutlinedButton(onClick = {
                            minutes = m
                            left = m * 60
                            running = false
                            completed = false
                        }) { Text("$m min") }
                    }
                }
            }
            Text(
                "${(left / 60).toString().padStart(2, '0')}:${(left % 60).toString().padStart(2, '0')}",
                fontSize = 64.sp,
                fontWeight = FontWeight.Bold,
                color = Navy
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = {
                    if (left == 0) left = minutes * 60
                    completed = false
                    running = !running
                }) { Text(if (running) "Pause" else "Start") }
                OutlinedButton(onClick = {
                    running = false
                    completed = false
                    left = minutes * 60
                }) { Text("Reset") }
            }
            if (completed) Text("Session complete! Take a short break.", fontWeight = FontWeight.Bold, color = Color(0xFF1B7A33))
            Text("Study sessions completed: ${app.sessions}", fontSize = 14.sp)
        }
    }
}

// ---------------------------------------------------------------- MCQ card, mock test, my notes

@Composable
fun McqCard(qi: Int, m: Mcq, chosen: Int?, reveal: Boolean, canPick: Boolean, onPick: (Int) -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Q${qi + 1}. ${m.question}", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            m.options.forEachIndexed { oi, opt ->
                val bg = when {
                    chosen == null -> Light
                    !reveal -> if (oi == chosen) Color(0xFFCFE3F7) else Light
                    oi == m.answer -> Good
                    oi == chosen -> Bad
                    else -> Light
                }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(bg)
                        .clickable(enabled = canPick) { onPick(oi) }
                        .padding(10.dp)
                ) {
                    Text("${"ABCD"[oi]}. $opt", fontSize = 14.sp)
                }
            }
            if (reveal) {
                if (chosen == null) {
                    Text("Not answered. Correct answer: ${"ABCD"[m.answer]}. ${m.options[m.answer]}", color = Color(0xFF8A5A00), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                } else if (chosen == m.answer) {
                    Text("Correct", color = Color(0xFF1B7A33), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                } else {
                    Text("Wrong. Correct answer: ${"ABCD"[m.answer]}. ${m.options[m.answer]}", color = Color(0xFFB00020), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun MockTestTab(topics: List<Topic>) {
    val app = LocalApp.current
    val all = remember(topics) { topics.flatMap { it.mcqs } }
    var questions by remember { mutableStateOf<List<Mcq>>(emptyList()) }
    val picks = remember { mutableStateMapOf<Int, Int>() }
    var running by remember { mutableStateOf(false) }
    var finished by remember { mutableStateOf(false) }
    val total = 25 * 60
    var left by remember { mutableStateOf(total) }

    LaunchedEffect(running) {
        while (running && left > 0) {
            delay(1000)
            left -= 1
        }
        if (running) {
            running = false
            finished = true
        }
    }
    LaunchedEffect(picks.size) {
        if (running && questions.isNotEmpty() && picks.size == questions.size) {
            running = false
            finished = true
        }
    }
    val correct = picks.count { (qi, c) -> qi < questions.size && questions[qi].answer == c }
    LaunchedEffect(finished) {
        if (finished) app.recordMock(correct)
    }

    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Light)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Mock Test", fontWeight = FontWeight.Bold, color = Navy, fontSize = 16.sp)
                    Text("25 random MCQs from all topics. Time: 25 minutes. Answers are shown when the test ends.", fontSize = 13.sp)
                    Text(
                        if (app.mockBest >= 0) "Best mock score: ${app.mockBest} / 25" else "Best mock score: not attempted yet",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (running) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                "Time left: ${left / 60}:${(left % 60).toString().padStart(2, '0')}",
                                fontWeight = FontWeight.Bold,
                                color = if (left <= 120) Color(0xFFB00020) else Ink
                            )
                            Button(onClick = {
                                running = false
                                finished = true
                            }) { Text("Submit") }
                        }
                        Text("Answered ${picks.size} / ${questions.size}", fontSize = 12.sp)
                    } else {
                        if (finished) {
                            val pct = if (questions.isEmpty()) 0 else correct * 100 / questions.size
                            Text("Score: $correct / ${questions.size} ($pct%)", fontWeight = FontWeight.Bold, color = Navy, fontSize = 16.sp)
                        }
                        Button(onClick = {
                            questions = all.shuffled().take(25)
                            picks.clear()
                            finished = false
                            left = total
                            running = true
                        }) { Text(if (finished) "New test" else "Start test") }
                    }
                }
            }
        }
        itemsIndexed(questions) { qi, m ->
            McqCard(
                qi = qi,
                m = m,
                chosen = picks[qi],
                reveal = finished,
                canPick = running && picks[qi] == null,
                onPick = { picks[qi] = it }
            )
        }
    }
}

@Composable
fun MyNotesTab(topic: Topic) {
    val app = LocalApp.current
    Column(Modifier.padding(12.dp)) {
        Text("Write your own notes for this topic. They are saved on this phone.", fontSize = 12.sp, color = Color(0xFF555555))
        OutlinedTextField(
            value = app.notes[topic.no] ?: "",
            onValueChange = { app.setNote(topic.no, it) },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            minLines = 8,
            placeholder = { Text("Type here...") }
        )
    }
}

// ---------------------------------------------------------------- Urdu translation with ML Kit

private suspend fun <T> Task<T>.awaitResult(): T = suspendCoroutine { cont ->
    addOnSuccessListener { value -> cont.resume(value) }
    addOnFailureListener { error -> cont.resumeWithException(error) }
}

private fun splitForTranslation(text: String): List<String> {
    val chunks = mutableListOf<String>()
    var cur = StringBuilder()
    text.split(Regex("(?<=[.!?])\\s+")).forEach { sentence ->
        if (cur.length + sentence.length + 1 > 600 && cur.isNotEmpty()) {
            chunks.add(cur.toString())
            cur = StringBuilder()
        }
        if (cur.isNotEmpty()) cur.append(' ')
        cur.append(sentence)
    }
    if (cur.isNotEmpty()) chunks.add(cur.toString())
    return chunks
}

/**
 * Translates English text to Urdu using ML Kit. The Urdu language model (about 30 MB) is
 * downloaded once over the internet; after that translation also works offline.
 */
suspend fun translateToUrdu(text: String, onStatus: (String) -> Unit): String {
    val options = TranslatorOptions.Builder()
        .setSourceLanguage(TranslateLanguage.ENGLISH)
        .setTargetLanguage(TranslateLanguage.URDU)
        .build()
    val translator = Translation.getClient(options)
    try {
        onStatus("Preparing the Urdu language model (first time needs internet, about 30 MB)...")
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).awaitResult()
        onStatus("Translating...")
        val out = StringBuilder()
        for (chunk in splitForTranslation(text)) {
            out.append(translator.translate(chunk).awaitResult()).append(' ')
        }
        return out.toString().trim()
    } finally {
        translator.close()
    }
}

@Composable
fun TranslateDialog(text: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var result by remember(text) { mutableStateOf<String?>(null) }
    var status by remember(text) { mutableStateOf("Starting...") }
    var error by remember(text) { mutableStateOf<String?>(null) }
    LaunchedEffect(text) {
        try {
            result = translateToUrdu(text) { status = it }
        } catch (e: Exception) {
            error = e.message ?: "Unknown error"
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Urdu translation (ML Kit)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val r = result
                val err = error
                if (r != null) {
                    Text(r, fontSize = 18.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                } else if (err != null) {
                    Text(
                        "Translation failed. Connect to the internet once so the Urdu language model can download, then try again.",
                        color = Color(0xFFB00020),
                        fontSize = 14.sp
                    )
                    Text(err, fontSize = 11.sp, color = Color(0xFF555555))
                } else {
                    Text(status, fontSize = 14.sp)
                }
                Text("Machine translation may not be perfect.", fontSize = 11.sp, color = Color(0xFF555555))
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        dismissButton = {
            TextButton(onClick = {
                val uri = Uri.parse("https://translate.google.com/?sl=en&tl=ur&op=translate&text=" + Uri.encode(text))
                context.startActivity(Intent(Intent.ACTION_VIEW, uri))
            }) { Text("Google Translate") }
        }
    )
}
