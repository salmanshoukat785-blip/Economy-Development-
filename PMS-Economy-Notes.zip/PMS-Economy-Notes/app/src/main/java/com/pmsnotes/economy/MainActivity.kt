@file:OptIn(ExperimentalMaterial3Api::class)

package com.pmsnotes.economy

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

private val Navy = Color(0xFF1F3A5F)
private val Teal = Color(0xFF0E7C86)
private val Amber = Color(0xFFFFF4DC)
private val AmberText = Color(0xFF8A5A00)
private val Ink = Color(0xFF1B1B1B)
private val VocabBlue = Color(0xFF0B5CAD)
private val Light = Color(0xFFEAF2F8)
private val Good = Color(0xFFD7F0DC)
private val Bad = Color(0xFFF8D7D7)

// ---------------------------------------------------------------- data

data class Item(val heading: String, val points: List<String>, val long: String)
data class Diff(val title: String, val text: String)
data class Mcq(val question: String, val options: List<String>, val answer: Int)
data class Topic(
    val no: Int,
    val section: String,
    val title: String,
    val items: List<Item>,
    val diffs: List<Diff>,
    val key: List<String>,
    val mcqs: List<Mcq>
)

class Vocab(val map: Map<String, String>) {
    val regex: Regex? = if (map.isEmpty()) null else Regex(
        "\\b(" + map.keys.sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) } + ")\\b",
        RegexOption.IGNORE_CASE
    )
}

data class SylEntry(val text: String, val topicNo: Int)
data class SylSection(val name: String, val entries: List<SylEntry>)
data class Syllabus(val header: List<String>, val sections: List<SylSection>, val note: String)

fun loadSyllabus(context: Context): Syllabus {
    val o = JSONObject(readAsset(context, "syllabus.json"))
    val ha = o.getJSONArray("header")
    val header = (0 until ha.length()).map { ha.getString(it) }
    val sa = o.getJSONArray("sections")
    val sections = (0 until sa.length()).map { i ->
        val so = sa.getJSONObject(i)
        val ea = so.getJSONArray("entries")
        SylSection(
            so.getString("name"),
            (0 until ea.length()).map { j ->
                val eo = ea.getJSONObject(j)
                SylEntry(eo.getString("t"), eo.getInt("n"))
            }
        )
    }
    return Syllabus(header, sections, o.optString("note", ""))
}

class VocabCtx(val vocab: Vocab, val show: (String) -> Unit)

val LocalVocab = staticCompositionLocalOf<VocabCtx> { error("Vocab not provided") }

fun readAsset(context: Context, name: String): String =
    context.assets.open(name).bufferedReader().use { it.readText() }

fun loadTopics(context: Context): List<Topic> {
    val arr = JSONArray(readAsset(context, "notes.json"))
    val result = mutableListOf<Topic>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        val items = mutableListOf<Item>()
        val ia = o.getJSONArray("items")
        for (j in 0 until ia.length()) {
            val io = ia.getJSONObject(j)
            val pa = io.getJSONArray("points")
            items.add(Item(io.getString("h"), (0 until pa.length()).map { pa.getString(it) }, io.optString("long", "")))
        }
        val diffs = mutableListOf<Diff>()
        val da = o.getJSONArray("diffs")
        for (j in 0 until da.length()) {
            val d = da.getJSONObject(j)
            diffs.add(Diff(d.getString("h"), d.getString("t")))
        }
        val ka = o.getJSONArray("key")
        val key = (0 until ka.length()).map { ka.getString(it) }
        val mq = o.getJSONArray("mcqs")
        val mcqs = mutableListOf<Mcq>()
        for (j in 0 until mq.length()) {
            val m = mq.getJSONObject(j)
            val oa = m.getJSONArray("o")
            mcqs.add(Mcq(m.getString("q"), (0 until oa.length()).map { oa.getString(it) }, m.getInt("a")))
        }
        result.add(Topic(o.getInt("no"), o.getString("section"), o.getString("title"), items, diffs, key, mcqs))
    }
    return result
}

fun loadVocab(context: Context): Vocab {
    val o = JSONObject(readAsset(context, "glossary.json"))
    val map = mutableMapOf<String, String>()
    val keys = o.keys()
    while (keys.hasNext()) {
        val k = keys.next()
        map[k.lowercase()] = o.getString(k)
    }
    return Vocab(map)
}

fun topicTerms(topic: Topic, vocab: Vocab): List<String> {
    val r = vocab.regex ?: return emptyList()
    val sb = StringBuilder(topic.title)
    topic.items.forEach {
        sb.append(' ').append(it.heading).append(' ').append(it.points.joinToString(" ")).append(' ').append(it.long)
    }
    topic.diffs.forEach { sb.append(' ').append(it.title).append(' ').append(it.text) }
    topic.key.forEach { sb.append(' ').append(it) }
    return r.findAll(sb).map { it.value.lowercase() }.distinct().sorted().toList()
}

fun buildVocabText(text: String, vocab: Vocab): AnnotatedString {
    val r = vocab.regex
    return buildAnnotatedString {
        if (r == null) {
            append(text)
        } else {
            var last = 0
            r.findAll(text).forEach { m ->
                append(text.substring(last, m.range.first))
                pushStringAnnotation("V", m.value.lowercase())
                withStyle(SpanStyle(textDecoration = TextDecoration.Underline, color = VocabBlue)) {
                    append(m.value)
                }
                pop()
                last = m.range.last + 1
            }
            append(text.substring(last))
        }
    }
}

// ---------------------------------------------------------------- UI helpers

@Composable
fun VText(
    text: String,
    modifier: Modifier = Modifier,
    size: TextUnit = 14.sp,
    color: Color = Ink,
    weight: FontWeight = FontWeight.Normal
) {
    val ctx = LocalVocab.current
    val annotated = remember(text, ctx.vocab) { buildVocabText(text, ctx.vocab) }
    ClickableText(
        text = annotated,
        modifier = modifier,
        style = TextStyle(fontSize = size, color = color, fontWeight = weight, lineHeight = size * 1.35f),
        onClick = { off ->
            annotated.getStringAnnotations("V", off, off).firstOrNull()?.let { ctx.show(it.item) }
        }
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val topics = loadTopics(this)
        val vocab = loadVocab(this)
        val syllabus = loadSyllabus(this)
        val state = AppState(applicationContext)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Navy)) {
                App(topics, vocab, syllabus, state)
            }
        }
    }
}

@Composable
fun App(topics: List<Topic>, vocab: Vocab, syllabus: Syllabus, state: AppState) {
    var selected by rememberSaveable { mutableStateOf(-1) }
    var stage by rememberSaveable { mutableStateOf(0) }
    var term by remember { mutableStateOf<String?>(null) }
    val ctx = remember(vocab) { VocabCtx(vocab) { term = it } }
    val base = LocalDensity.current
    BackHandler(enabled = stage == 2 && selected >= 0) { selected = -1 }

    LaunchedEffect(state.timerRunning) {
        while (state.timerRunning && state.timerLeft > 0) {
            delay(1000)
            state.timerLeft = state.timerLeft - 1
        }
        if (state.timerRunning) {
            state.timerRunning = false
            state.finishSession()
        }
    }

    CompositionLocalProvider(
        LocalVocab provides ctx,
        LocalState provides state,
        LocalDensity provides Density(base.density, base.fontScale * state.fontScale)
    ) {
        when (stage) {
            0 -> SplashScreen { stage = if (state.welcomed) 2 else 1 }
            1 -> WelcomeScreen {
                state.markWelcomed()
                stage = 2
            }
            else -> {
                if (selected < 0) {
                    HomeScreen(topics, syllabus, { stage = 1 }) { idx ->
                        selected = idx
                        state.openTopic(topics[idx].no)
                    }
                } else {
                    TopicScreen(topics[selected]) { selected = -1 }
                }
            }
        }
        val t = term
        if (t != null) {
            AlertDialog(
                onDismissRequest = { term = null },
                confirmButton = { TextButton(onClick = { term = null }) { Text("Close") } },
                title = { Text(t.replaceFirstChar { it.uppercase() }) },
                text = {
                    Text(
                        vocab.map[t] ?: "",
                        fontSize = 24.sp,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            )
        }
    }
}

@Composable
fun BarTitle(text: String) {
    Text(text, fontSize = 16.sp, maxLines = 2)
}

@Composable
fun HomeScreen(topics: List<Topic>, syllabus: Syllabus, onWelcome: () -> Unit, onOpen: (Int) -> Unit) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val titles = listOf("Topics", "Saved", "Course Outline", "Topic Outline", "Study", "Guide")
    Scaffold(
        topBar = {
            TopAppBar(
                title = { BarTitle("Economy and Development") },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Color.White)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
                titles.forEachIndexed { i, s ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(s, fontSize = 12.sp, maxLines = 1) })
                }
            }
            when (tab) {
                0 -> TopicList(topics, false, onOpen)
                1 -> TopicList(topics, true, onOpen)
                2 -> CourseOutlineTab(topics, syllabus, onOpen)
                3 -> OutlineTab(topics, onOpen)
                4 -> StudyTab(topics, onOpen)
                else -> GuideTab(onWelcome)
            }
        }
    }
}

@Composable
fun TopicList(topics: List<Topic>, onlySaved: Boolean, onOpen: (Int) -> Unit) {
    val st = LocalState.current
    var query by rememberSaveable { mutableStateOf("") }
    val savedCount = st.saved.size
    val filtered = remember(query, topics, onlySaved, savedCount) {
        val q = query.trim().lowercase()
        topics.withIndex().filter { (_, t) ->
            val inScope = !onlySaved || st.saved.contains(t.no)
            val matches = q.isEmpty() || t.title.lowercase().contains(q) ||
                t.items.any { it.heading.lowercase().contains(q) || it.long.lowercase().contains(q) }
            inScope && matches
        }
    }
    Column {
        if (!onlySaved) {
            Column(Modifier.padding(start = 12.dp, end = 12.dp, top = 8.dp)) {
                Text("Studied ${st.studied.size} / ${topics.size}", fontSize = 12.sp, color = Color(0xFF555555))
                LinearProgressIndicator(
                    progress = { if (topics.isEmpty()) 0f else st.studied.size.toFloat() / topics.size },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            placeholder = { Text("Search topics or terms") },
            singleLine = true
        )
        if (onlySaved && filtered.isEmpty()) {
            Text(
                "No saved topics yet. Open a topic and tap Save.",
                modifier = Modifier.padding(16.dp),
                color = Color(0xFF555555)
            )
        }
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            var last = ""
            filtered.forEach { (idx, t) ->
                if (t.section != last) {
                    last = t.section
                    val name = last
                    item(key = "sec_$name") { SectionBar(name) }
                }
                item(key = "topic_$idx") {
                    val mark = (if (st.saved.contains(t.no)) "★ " else "") + (if (st.studied.contains(t.no)) "✓ " else "")
                    Card(
                        onClick = { onOpen(idx) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Light)
                    ) {
                        Text(
                            mark + t.title,
                            modifier = Modifier.padding(14.dp),
                            color = Ink,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SectionBar(name: String) {
    Text(
        name,
        modifier = Modifier
            .fillMaxWidth()
            .background(Navy)
            .padding(10.dp),
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp
    )
}

@Composable
fun CourseOutlineTab(topics: List<Topic>, syllabus: Syllabus, onOpen: (Int) -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                syllabus.header.forEachIndexed { i, line ->
                    Text(
                        line,
                        fontWeight = if (i < 3) FontWeight.Bold else FontWeight.Normal,
                        fontSize = if (i == 0) 16.sp else 13.sp,
                        color = if (i < 3) Navy else Color(0xFF555555)
                    )
                }
            }
        }
        syllabus.sections.forEachIndexed { si, sec ->
            item(key = "csec_$si") { SectionBar(sec.name) }
            itemsIndexed(sec.entries) { i, entry ->
                val idx = topics.indexOfFirst { it.no == entry.topicNo }
                Card(
                    onClick = { if (idx >= 0) onOpen(idx) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = if (i % 2 == 0) Light else Color.White)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${i + 1}. ${entry.text}", fontSize = 14.sp, color = Ink)
                        Text("Open topic ${entry.topicNo}", fontSize = 11.sp, color = Teal)
                    }
                }
            }
        }
        item {
            if (syllabus.note.isNotEmpty()) {
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Amber)) {
                    Text(syllabus.note, modifier = Modifier.padding(12.dp), fontSize = 12.sp, color = AmberText)
                }
            }
        }
    }
}

@Composable
fun OutlineTab(topics: List<Topic>, onOpen: (Int) -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        var last = ""
        topics.forEachIndexed { idx, t ->
            if (t.section != last) {
                last = t.section
                val name = last
                item(key = "osec_$name") { SectionBar(name) }
            }
            item(key = "otopic_$idx") {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onOpen(idx) }
                        .padding(vertical = 4.dp)
                ) {
                    Text(t.title, fontWeight = FontWeight.Bold, color = Navy, fontSize = 14.sp)
                    t.items.forEachIndexed { i, it ->
                        Text("   ${i + 1}. ${it.heading}", fontSize = 12.sp, color = Ink)
                        if (it.points.size > 1) {
                            Text("        – " + it.points.joinToString(" • "), fontSize = 11.sp, color = Color(0xFF555555))
                        }
                    }
                    Text("   Differences: " + t.diffs.joinToString("; ") { it.title }, fontSize = 11.sp, color = AmberText)
                }
            }
        }
    }
}

@Composable
fun TopicScreen(topic: Topic, onBack: () -> Unit) {
    val st = LocalState.current
    var tab by rememberSaveable { mutableStateOf(0) }
    val titles = listOf("Notes", "Key Points", "MCQs", "Vocabulary", "My Notes")
    val isSaved = st.saved.contains(topic.no)
    val isStudied = st.studied.contains(topic.no)
    Scaffold(
        topBar = {
            TopAppBar(
                title = { BarTitle(topic.title) },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back", color = Color.White) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Color.White)
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(onClick = { st.toggleSaved(topic.no) }) {
                    Text(if (isSaved) "★ Saved" else "☆ Save", fontSize = 12.sp)
                }
                OutlinedButton(onClick = { st.toggleStudied(topic.no) }) {
                    Text(if (isStudied) "✓ Studied" else "Mark studied", fontSize = 12.sp)
                }
            }
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
                titles.forEachIndexed { i, s ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(s, fontSize = 12.sp, maxLines = 1) })
                }
            }
            when (tab) {
                0 -> NotesTab(topic)
                1 -> KeyPointsTab(topic)
                2 -> McqTab(topic)
                3 -> VocabTab(topic)
                else -> MyNotesTab(topic)
            }
        }
    }
}

@Composable
fun NotesTab(topic: Topic) {
    var long by rememberSaveable { mutableStateOf(false) }
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Short", modifier = Modifier.padding(top = 12.dp), fontWeight = if (!long) FontWeight.Bold else FontWeight.Normal)
            Switch(checked = long, onCheckedChange = { long = it })
            Text("Long detail", modifier = Modifier.padding(top = 12.dp), fontWeight = if (long) FontWeight.Bold else FontWeight.Normal)
        }
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(topic.items) { i, entry ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = if (i % 2 == 0) Light else Color.White)
                ) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("${i + 1}. ${entry.heading}", color = Teal, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        if (long && entry.long.isNotEmpty()) {
                            VText(entry.long)
                        } else if (entry.points.size == 1) {
                            VText(entry.points[0])
                        } else {
                            entry.points.forEach { p -> VText("• $p") }
                        }
                    }
                }
            }
            item {
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Amber)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("DIFFERENCES", color = AmberText, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        topic.diffs.forEach { d -> VText("${d.title} – ${d.text}") }
                    }
                }
            }
        }
    }
}

@Composable
fun KeyPointsTab(topic: Topic) {
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        itemsIndexed(topic.key) { i, k ->
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = if (i % 2 == 0) Light else Color.White)) {
                Row(Modifier.padding(12.dp)) {
                    Text("★ ", color = Teal, fontWeight = FontWeight.Bold)
                    VText(k)
                }
            }
        }
    }
}

@Composable
fun McqTab(topic: Topic) {
    val picks = remember(topic.no) { mutableStateMapOf<Int, Int>() }
    var timed by rememberSaveable { mutableStateOf(false) }
    var running by remember(topic.no) { mutableStateOf(false) }
    var finished by remember(topic.no) { mutableStateOf(false) }
    val total = topic.mcqs.size * 30
    var left by remember(topic.no) { mutableStateOf(total) }

    LaunchedEffect(running) {
        while (running && left > 0) {
            delay(1000)
            left -= 1
        }
        if (running) {
            running = false
            finished = true
        }
    }
    LaunchedEffect(picks.size) {
        if (timed && running && picks.size == topic.mcqs.size) {
            running = false
            finished = true
        }
    }

    val reveal = !timed || finished
    val answered = picks.size
    val correct = picks.count { (qi, choice) -> topic.mcqs[qi].answer == choice }
    val selectedColor = Color(0xFFCFE3F7)
    val st = LocalState.current
    LaunchedEffect(picks.size, finished) {
        if ((!timed && picks.size == topic.mcqs.size) || (timed && finished)) {
            st.recordBest(topic.no, correct)
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Practice", modifier = Modifier.padding(top = 12.dp), fontWeight = if (!timed) FontWeight.Bold else FontWeight.Normal)
                    Switch(
                        checked = timed,
                        onCheckedChange = {
                            timed = it
                            picks.clear()
                            running = false
                            finished = false
                            left = total
                        }
                    )
                    Text("Timed test (30 s per question)", modifier = Modifier.padding(top = 12.dp), fontWeight = if (timed) FontWeight.Bold else FontWeight.Normal, fontSize = 13.sp)
                }
                if (timed) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            "Time left: ${left / 60}:${(left % 60).toString().padStart(2, '0')}",
                            fontWeight = FontWeight.Bold,
                            color = if (left <= 30) Color(0xFFB00020) else Ink
                        )
                        if (!running) {
                            Button(onClick = {
                                picks.clear()
                                finished = false
                                left = total
                                running = true
                            }) { Text(if (finished) "Retry" else "Start") }
                        }
                    }
                    if (finished) {
                        Text(
                            if (left == 0) "Time up! Score: $correct / ${topic.mcqs.size}" else "Finished! Score: $correct / ${topic.mcqs.size}",
                            fontWeight = FontWeight.Bold,
                            color = Navy
                        )
                    } else if (!running) {
                        Text("Press Start. Answers are shown when the test ends.", fontSize = 12.sp, color = Color(0xFF555555))
                    } else {
                        Text("Answered $answered / ${topic.mcqs.size}", fontSize = 12.sp)
                    }
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Score: $correct / $answered answered (${topic.mcqs.size} total)", fontWeight = FontWeight.Bold)
                        TextButton(onClick = { picks.clear() }) { Text("Reset") }
                    }
                }
            }
        }
        itemsIndexed(topic.mcqs) { qi, m ->
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Q${qi + 1}. ${m.question}", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    val chosen = picks[qi]
                    val canPick = chosen == null && (!timed || running)
                    m.options.forEachIndexed { oi, opt ->
                        val bg = when {
                            chosen == null -> Light
                            !reveal -> if (oi == chosen) selectedColor else Light
                            oi == m.answer -> Good
                            oi == chosen -> Bad
                            else -> Light
                        }
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .background(bg)
                                .clickable(enabled = canPick) { picks[qi] = oi }
                                .padding(10.dp)
                        ) {
                            Text("${"ABCD"[oi]}. $opt", fontSize = 14.sp)
                        }
                    }
                    if (chosen != null && reveal) {
                        Text(
                            if (chosen == m.answer) "Correct" else "Wrong. Correct answer: ${"ABCD"[m.answer]}. ${m.options[m.answer]}",
                            color = if (chosen == m.answer) Color(0xFF1B7A33) else Color(0xFFB00020),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun VocabTab(topic: Topic) {
    val ctx = LocalVocab.current
    val terms = remember(topic.no) { topicTerms(topic, ctx.vocab) }
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        item { Text("Underlined words in the notes open the same Urdu meanings.", fontSize = 12.sp, color = Color(0xFF555555)) }
        itemsIndexed(terms) { i, t ->
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = if (i % 2 == 0) Light else Color.White)) {
                Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(t.replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text(ctx.vocab.map[t] ?: "", fontSize = 18.sp, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}
