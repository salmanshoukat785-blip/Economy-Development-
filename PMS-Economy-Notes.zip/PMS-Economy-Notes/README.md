# PMS Economy Notes (Android, Kotlin)

Offline revision app for Punjab PMS Paper 10: Economy and Development.

## Features
- 56 topics in three sections (A, B, C), each with 10+ headings and a Differences box (symbols).
- **Notes tab:** switch between Short and Long detail for every heading.
- **Key Points tab:** quick facts, formulas and differences per topic.
- **MCQs tab:** 10 MCQs per topic (560 total) with instant correct/wrong feedback and score.
- **Vocabulary:** terms are underlined in the notes; tap one to see its Urdu meaning. A Vocabulary tab lists all terms in the topic.
- **Course Outline tab (home screen):** the official syllabus from your file (Sections A, B, C, 66 lines); tap a line to open the matching topic.
- **Topic Outline tab:** headings and sub-points of every topic.
- **Timed MCQ test:** switch on Timed mode (30 seconds per question), press Start, and answers are shown when time ends.
- Works fully offline; the app uses no mobile data.

## Get the APK from GitHub
1. Create a new GitHub repository and push this folder to the `main` branch.
2. Open the **Actions** tab, then the **Build APK** workflow.
3. When the run finishes, download the artifact **PMS-Economy-Notes-debug-apk** and install `app-debug.apk`.

## Build locally
Open the folder in Android Studio and press Run, or use Gradle 8.7 with JDK 17: `gradle assembleDebug`.

## Editing content
- `app/src/main/assets/notes.json`: topics, short/long text, key points, MCQs.
- `app/src/main/assets/syllabus.json`: course outline.
- `app/src/main/assets/glossary.json`: vocabulary terms and Urdu meanings (keys in lowercase).
