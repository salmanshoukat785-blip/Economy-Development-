package com.pmsnotes.economy

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val XNavy = Color(0xFF1F3A5F)
private val XTeal = Color(0xFF0E7C86)
private val XLight = Color(0xFFEAF2F8)
private val XInk = Color(0xFF1B1B1B)

const val FOCUS_SECONDS = 25 * 60

val LocalState = staticCompositionLocalOf<AppState> { error("State not provided") }

class AppState(context: Context) {
    private val prefs = context.getSharedPreferences("study", Context.MODE_PRIVATE)
    val studied = mutableStateListOf<Int>()
    val saved = mutableStateListOf<Int>()
    val best = mutableStateMapOf<Int, Int>()
    val notes = mutableStateMapOf<Int, String>()
    var fontScale by mutableStateOf(1f)
    var welcomed by mutableStateOf(false)
    var lastTopic by mutableStateOf(-1)
    var sessions by mutableStateOf(0)
    var timerLeft by mutableStateOf(FOCUS_SECONDS)
    var timerRunning by mutableStateOf(false)

    init {
        prefs.getStringSet("studied", emptySet())?.forEach { s -> s.toIntOrNull()?.let { studied.add(it) } }
        prefs.getStringSet("saved", emptySet())?.forEach { s -> s.toIntOrNull()?.let { saved.add(it) } }
        for ((k, v) in prefs.all) {
            if (k.startsWith("best_") && v is Int) k.removePrefix("best_").toIntOrNull()?.let { best[it] = v }
            if (k.startsWith("note_") && v is String) k.removePrefix("note_").toIntOrNull()?.let { notes[it] = v }
        }
        fontScale = prefs.getFloat("font", 1f)
        welcomed = prefs.getBoolean("welcomed", false)
        lastTopic = prefs.getInt("last", -1)
        sessions = prefs.getInt("sessions", 0)
    }

    private fun saveSet(key: String, list: List<Int>) {
        prefs.edit().putStringSet(key, list.map { it.toString() }.toSet()).apply()
    }

    fun toggleStudied(no: Int) {
        if (studied.contains(no)) studied.remove(no) else studied.add(no)
        saveSet("studied", studied)
    }

    fun toggleSaved(no: Int) {
        if (saved.contains(no)) saved.remove(no) else saved.add(no)
        saveSet("saved", saved)
    }

    fun recordBest(no: Int, score: Int) {
        val old = best[no] ?: -1
        if (score > old) {
            best[no] = score
            prefs.edit().putInt("best_$no", score).apply()
        }
    }

    fun setNote(no: Int, text: String) {
        notes[no] = text
        prefs.edit().putString("note_$no", text).apply()
    }

    fun changeFont(delta: Float) {
        fontScale = (fontScale + delta).coerceIn(0.8f, 1.4f)
        prefs.edit().putFloat("font", fontScale).apply()
    }

    fun markWelcomed() {
        welcomed = true
        prefs.edit().putBoolean("welcomed", true).apply()
    }

    fun openTopic(no: Int) {
        lastTopic = no
        prefs.edit().putInt("last", no).apply()
    }

    fun finishSession() {
        sessions += 1
        prefs.edit().putInt("sessions", sessions).apply()
        timerLeft = FOCUS_SECONDS
    }

    fun resetTimer() {
        timerRunning = false
        timerLeft = FOCUS_SECONDS
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1800)
        onDone()
    }
    Box(Modifier.fillMaxSize().background(XNavy), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.logo_white), contentDescription = null, modifier = Modifier.size(140.dp))
            Spacer(Modifier.height(24.dp))
            Text("Economy and Development", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Text("Punjab PMS | Paper 10", color = Color(0xFFB8C7D9), fontSize = 14.sp)
        }
    }
}

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    val points = listOf(
        "56 topics following the PMS syllabus",
        "Short and Long detail for every heading",
        "Tap underlined words to see Urdu meanings",
        "10 MCQs per topic with a timed test",
        "Save topics, mark studied and track progress",
        "Write your own notes and use the study timer",
        "Works offline, no internet or mobile data needed"
    )
    Column(
        Modifier
            .fillMaxSize()
            .background(Color.White)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))
        Image(painterResource(R.drawable.logo_navy), contentDescription = null, modifier = Modifier.size(110.dp))
        Spacer(Modifier.height(16.dp))
        Text("Welcome to", fontSize = 16.sp, color = Color(0xFF555555))
        Text("Economy and Development", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = XNavy, textAlign = TextAlign.Center)
        Spacer(Modifier.height(4.dp))
        Text("Punjab PMS | Paper 10 | 100 marks", fontSize = 13.sp, color = XTeal)
        Spacer(Modifier.height(20.dp))
        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = XLight)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("What you can do", fontWeight = FontWeight.Bold, color = XNavy)
                points.forEach { p -> Text("✓  $p", fontSize = 14.sp, color = XInk) }
            }
        }
        Spacer(Modifier.height(24.dp))
        Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) { Text("Get Started") }
        Spacer(Modifier.height(8.dp))
        Text("You can read the User Guide any time from the Guide tab.", fontSize = 12.sp, color = Color(0xFF555555), textAlign = TextAlign.Center)
    }
}

private val guideItems = listOf(
    "Getting started" to "Open the Topics tab and tap a topic. Topics follow the syllabus in three sections: A (Indicators and Terms), B (Concepts) and C (Economy of Pakistan). Use the search box to find a topic or a term.",
    "Notes: Short and Long" to "Inside a topic, the Notes tab shows every heading. Use the Short / Long detail switch: Short gives quick points, Long gives a full explanation. The Differences box at the bottom compares related terms with symbols.",
    "Vocabulary (Urdu meanings)" to "Words underlined in blue are vocabulary terms. Tap one to see its Urdu meaning in a popup. The Vocabulary tab lists all terms of the topic.",
    "Key Points" to "The Key Points tab gives definitions, formulas, Pakistan facts and differences for fast revision.",
    "MCQs and timed test" to "Each topic has 10 MCQs. In Practice mode, tap an option to see the answer at once. Switch on Timed test, press Start, and you get 30 seconds per question. Answers and score appear when the test ends. Your best score is saved.",
    "Save and Mark studied" to "In a topic, tap Save to keep it in the Saved tab, and Mark studied when you finish it. Studied topics show a tick on the Topics list and count towards your progress.",
    "My Notes" to "The My Notes tab lets you write your own notes for each topic. They save automatically on your phone.",
    "Course Outline and Topic Outline" to "Course Outline shows the official syllabus lines from your file; tap a line to open its topic. Topic Outline shows the headings and sub-points of every topic.",
    "Study tab" to "See your progress bar, continue from the last topic you opened, run a 25-minute focus timer, change the text size and view your best MCQ scores.",
    "Offline and privacy" to "All content is stored inside the app, so no internet or mobile data is needed. Your progress, saved topics and notes stay only on your phone.",
    "Please verify" to "Figures such as dates, shares and amounts are approximate. Before the exam, check the latest Pakistan Economic Survey, SBP data and the official PPSC syllabus."
)

@Composable
fun GuideTab(onWelcome: () -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { Text("User Guide", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = XNavy) }
        guideItems.forEachIndexed { i, (title, body) ->
            item(key = "guide_$i") {
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = if (i % 2 == 0) XLight else Color.White)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("${i + 1}. $title", fontWeight = FontWeight.Bold, color = XTeal, fontSize = 14.sp)
                        Text(body, fontSize = 14.sp, color = XInk)
                    }
                }
            }
        }
        item {
            OutlinedButton(onClick = onWelcome, modifier = Modifier.fillMaxWidth()) { Text("Show welcome page") }
        }
        item { Text("Economy and Development | Version 2.0", fontSize = 11.sp, color = Color(0xFF777777)) }
    }
}

@Composable
fun StudyTab(topics: List<Topic>, onOpen: (Int) -> Unit) {
    val st = LocalState.current
    val idx = topics.indexOfFirst { it.no == st.lastTopic }
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = XLight)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Your progress", fontWeight = FontWeight.Bold, color = XNavy)
                    LinearProgressIndicator(
                        progress = { if (topics.isEmpty()) 0f else st.studied.size.toFloat() / topics.size },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("${st.studied.size} of ${topics.size} topics studied | ${st.saved.size} saved", fontSize = 13.sp)
                    if (idx >= 0) {
                        Button(onClick = { onOpen(idx) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Continue: " + topics[idx].title, maxLines = 1)
                        }
                    }
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = XLight)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Focus timer (25 minutes)", fontWeight = FontWeight.Bold, color = XNavy)
                    Text(
                        "${st.timerLeft / 60}:${(st.timerLeft % 60).toString().padStart(2, '0')}",
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Bold,
                        color = XTeal
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { st.timerRunning = !st.timerRunning }) {
                            Text(if (st.timerRunning) "Pause" else "Start")
                        }
                        OutlinedButton(onClick = { st.resetTimer() }) { Text("Reset") }
                    }
                    Text("Completed sessions: ${st.sessions}", fontSize = 13.sp)
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = XLight)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Text size", fontWeight = FontWeight.Bold, color = XNavy)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { st.changeFont(-0.1f) }) { Text("A−") }
                        Text("${(st.fontScale * 100).toInt()}%", fontWeight = FontWeight.Bold)
                        OutlinedButton(onClick = { st.changeFont(0.1f) }) { Text("A+") }
                    }
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = XLight)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Best MCQ scores", fontWeight = FontWeight.Bold, color = XNavy)
                    if (st.best.isEmpty()) {
                        Text("No MCQ results yet.", fontSize = 13.sp)
                    } else {
                        st.best.keys.sorted().forEach { no ->
                            val t = topics.firstOrNull { it.no == no }
                            Text("Topic $no: ${st.best[no]} / ${t?.mcqs?.size ?: 10}", fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MyNotesTab(topic: Topic) {
    val st = LocalState.current
    Column(Modifier.padding(12.dp)) {
        Text("Write your own notes for this topic. They are saved on this phone automatically.", fontSize = 12.sp, color = Color(0xFF555555))
        OutlinedTextField(
            value = st.notes[topic.no] ?: "",
            onValueChange = { st.setNote(topic.no, it) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            minLines = 8
        )
    }
}
